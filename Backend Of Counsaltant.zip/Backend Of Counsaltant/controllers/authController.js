const userModel = require("../models/user-model");
const bcrypt = require("bcrypt");
const generateToken = require("../utils/generateToken");

module.exports.registerUser = async (req, res) => {
    const { name, email, password } = req.body;

    try {
        // Check if user already exists
        let user = await userModel.findOne({ email });
        if (user) {
            return res.status(400).send("Your account already exists, please login.");
        }

        // Ensure password is defined and not empty
        if (!password) {
            return res.status(400).send("Password is required.");
        }

        // Generate salt and hash the password
        let salt = await bcrypt.genSalt(10); // Specify the number of salt rounds
        let hash = await bcrypt.hash(password, salt);

        // Create new user
        user = await userModel.create({
            email,
            password: hash,
            name,
        });

        // Generate JWT token
        let token = generateToken({ email });


        res.cookie("token", token, {
            httpOnly: true,
            secure: true,
            maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
        });

        res.status(201).send(user);
    } catch (err) {
        console.error("Error during registration:", err); // Log the exact error
        res.status(500).send({ error: err.message });
    }
};

module.exports.loginUser = async (req, res) => {
    const { email, password } = req.body;

    try {
        let user = await userModel.findOne({ email });
        if (!user) {
            return res.status(400).send("Email or Password is incorrect.");
        }

        // Compare password with hashed password
        let result = await bcrypt.compare(password, user.password);
        if (result) {
            let token = generateToken({ email });

            res.cookie("token", token, {
                httpOnly: true,
                secure: true,
                maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
            });

            res.status(201).send("logged in successfully"); // Use 200 for successful login
        } else {
            return res.status(400).send("Email or Password is incorrect.");
        }
    } catch (err) {
        console.error("Error during login:", err); // Log the exact error
        res.status(500).send({ error: err.message });   
    }
};

module.exports.logoutUser = function (req, res) {
    res.cookie("token", "", {
        httpOnly: true,
        secure: true,
        
    });

    res.status(201).send("logged out successfully");
};

module.exports.getUserProfile = function (req, res) {
    console.log(req.user);
    res.send("Logged in ho aap");
};
